BBGA code:

# Structure

BBGA.py the main program.
attack.py the BBGA attacking model.

# Usage
command for experiments reported in the paper:

python BBGA.py --dataset cora --ptb_rate 0.8 --k 5

replace cora with the dataset name and assign hyperparameters 0.8 and 5. Datasets we used are from https://github.com/danielzuegner/gnn-meta-attack/tree/master/data.